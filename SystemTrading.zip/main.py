# from api.Kiwoom import *
from strategy.RSIStrategy import *
import sys

app = QApplication(sys.argv)

rsi_strategy = RSIStrategy()
rsi_strategy.start()

app.exec_()

# kiwoom = Kiwoom()
# kiwoom.get_account_number()

'''
kospi_code_list = kiwoom.get_code_list_by_market("0") # 코스피에 상장된 종목 코드를 얻어 옴
print(kospi_code_list)
for code in kospi_code_list:
    code_name = kiwoom.get_master_code_name(code)
    print(code, code_name)

kosdaq_code_list = kiwoom.get_code_list_by_market("10") # 코스닥에 상장된 종목 코드를 얻어 옴
print(kosdaq_code_list)
for code in kosdaq_code_list:
    code_name = kiwoom.get_master_code_name(code)
    print(code, code_name)

df = kiwoom.get_price_data("005930")    # 삼성전자(005930)의 일봉 정보를 출력
print(df)

deposit = kiwoom.get_deposit()

order_result = kiwoom.send_order('send_buy_order', '1001', 1, '007700', 1, 26200, '00')
print(order_result)

orders = kiwoom.get_order()
print(orders)

position = kiwoom.get_balance()
print(position)

# kiwoom.set_real_reg("1000", "", "get_fid("장운영구분"), "0")   # 장 시작 시간 확인
fids = get_fid("체결시간")
codes = '005930;007700;000660;'
kiwoom.set_real_reg("1000", codes, fids, "0")

app.exec()
'''